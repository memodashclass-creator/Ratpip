مشروع Android (Kotlin) لتطبيق "راتبي"
-----------------------------------
المحتوى: مشروع Android Studio جاهز (مصدر).

كيف تبني APK:
1. افتح Android Studio.
2. اختر 'Open' و اختر المجلد الذي يحتوي على هذا المشروع (مجلد 'Ratibi' في ZIP).
3. Android Studio سيقوم بمزامنة Gradle. إذا طُلب، قم بإنشاء Gradle wrapper أو السماح للأندرويد ستوديو بتحميل المكونات.
4. من قائمة Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. بعد انتهاء البناء، سيظهر رابط لتحميل الـ APK داخل Android Studio أو في build/outputs/apk/debug/app-debug.apk

ملاحظات:
- المشروع مُصمم ليعمل على Android 8.0 (API 26) فما فوق.
- هذا مشروع أصلي (Kotlin). يقوم بتخزين بنيّة المعادلات فقط في SharedPreferences (بدون حفظ أرقام الحساب).
- إذا أردت، أستطيع شرح خطوة بخطوة كيف تبني الـ APK على جهازك أو أساعد بتوليد keystore للتوقيع الرسمي.
