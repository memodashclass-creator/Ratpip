package com.ratibi.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemsAdapter(private val items: List<Item>, private val onDelete: (Int)->Unit) : RecyclerView.Adapter<ItemsAdapter.VH>() {
    class VH(view: View): RecyclerView.ViewHolder(view){
        val name = view.findViewById<TextView>(R.id.item_name)
        val sub = view.findViewById<TextView>(R.id.item_sub)
        val del = view.findViewById<Button>(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val it = items[position]
        holder.name.text = it.name
        holder.sub.text = "${it.type} - ${it.value}"
        holder.del.setOnClickListener { onDelete(position) }
    }

    override fun getItemCount(): Int = items.size
}
