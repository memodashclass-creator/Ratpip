package com.ratibi.app

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

data class Item(val name: String, val type: String, val value: Double)

class MainActivity : AppCompatActivity() {

    private lateinit var salaryInput: EditText
    private lateinit var addBtn: Button
    private lateinit var calcBtn: Button
    private lateinit var saveFormulaBtn: Button
    private lateinit var chooseFormulaBtn: Button
    private lateinit var newBtn: Button
    private lateinit var resultText: TextView
    private lateinit var recycler: RecyclerView
    private val items = mutableListOf<Item>()
    private lateinit var adapter: ItemsAdapter

    private val PREFS = "ratibi_prefs"
    private val FORMULAS_KEY = "saved_formulas"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // set layout programmatically to ensure RTL and white background
        setContentView(R.layout.activity_main)

        salaryInput = findViewById(R.id.salary_input)
        addBtn = findViewById(R.id.btn_add)
        calcBtn = findViewById(R.id.btn_calc)
        saveFormulaBtn = findViewById(R.id.btn_save_formula)
        chooseFormulaBtn = findViewById(R.id.btn_choose_formula)
        newBtn = findViewById(R.id.btn_new)
        resultText = findViewById(R.id.result_text)
        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ItemsAdapter(items) { pos ->
            items.removeAt(pos)
            adapter.notifyDataSetChanged()
        }
        recycler.adapter = adapter

        addBtn.setOnClickListener { showAddDialog() }
        calcBtn.setOnClickListener { calculate() }
        newBtn.setOnClickListener { items.clear(); adapter.notifyDataSetChanged(); resultText.text = "" }
        saveFormulaBtn.setOnClickListener { showSaveFormulaDialog() }
        chooseFormulaBtn.setOnClickListener { showChooseFormulaDialog() }
    }

    private fun showAddDialog(){
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.dialog_add, null)
        val nameInput = view.findViewById<EditText>(R.id.item_name)
        val typeSpinner = view.findViewById<Spinner>(R.id.type_spinner)
        val valueInput = view.findViewById<EditText>(R.id.value_input)
        valueInput.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

        val dialog = AlertDialog.Builder(this)
            .setTitle("إضافة فقرة")
            .setView(view)
            .setPositiveButton("حفظ") { d, _ ->
                val n = nameInput.text.toString().trim()
                val t = typeSpinner.selectedItem.toString()
                val v = valueInput.text.toString().toDoubleOrNull() ?: 0.0
                if(n.isNotEmpty()){
                    items.add(Item(n, t, v))
                    adapter.notifyDataSetChanged()
                } else {
                    Toast.makeText(this, "رجاءً اكتب اسم الفقرة", Toast.LENGTH_SHORT).show()
                }
                d.dismiss()
            }
            .setNegativeButton("إلغاء"){ d, _ -> d.dismiss() }
            .create()
        dialog.show()
    }

    private fun calculate(){
        val base = salaryInput.text.toString().toDoubleOrNull() ?: 0.0
        var total = base
        for(i in items){
            when(i.type){
                "إضافة (مبلغ)" -> total += i.value
                "استقطاع (مبلغ)" -> total -= i.value
                "% نسبة من الاسمي" -> total += base * (i.value / 100.0)
            }
        }
        // show single final number without currency
        resultText.text = String.format("%.2f", total)
    }

    private fun showSaveFormulaDialog(){
        val input = EditText(this)
        input.hint = "اسم العنوان الوظيفي"
        input.gravity = Gravity.RIGHT
        AlertDialog.Builder(this)
            .setTitle("حفظ المعادلة")
            .setView(input)
            .setPositiveButton("حفظ"){ d, _ ->
                val name = input.text.toString().trim()
                if(name.isEmpty()){
                    Toast.makeText(this, "أدخل اسمًا لحفظ المعادلة", Toast.LENGTH_SHORT).show()
                } else {
                    saveFormula(name)
                    Toast.makeText(this, "تم حفظ المعادلة بنجاح", Toast.LENGTH_SHORT).show()
                }
                d.dismiss()
            }
            .setNegativeButton("إلغاء"){ d, _ -> d.dismiss() }
            .show()
    }

    private fun saveFormula(name: String){
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val all = prefs.getString(FORMULAS_KEY, "[]")
        val arr = JSONArray(all)
        val obj = JSONObject()
        obj.put("name", name)
        val itemsArr = JSONArray()
        for(it in items){
            val itObj = JSONObject()
            itObj.put("name", it.name)
            itObj.put("type", it.type)
            itObj.put("value", it.value)
            itemsArr.put(itObj)
        }
        obj.put("items", itemsArr)
        arr.put(obj)
        prefs.edit().putString(FORMULAS_KEY, arr.toString()).apply()
    }

    private fun showChooseFormulaDialog(){
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val all = prefs.getString(FORMULAS_KEY, "[]")
        val arr = JSONArray(all)
        val names = mutableListOf<String>()
        for(i in 0 until arr.length()){
            val o = arr.getJSONObject(i)
            names.add(o.getString("name"))
        }
        if(names.isEmpty()){
            Toast.makeText(this, "ماكو معادلات محفوظة", Toast.LENGTH_SHORT).show()
            return
        }
        val builder = AlertDialog.Builder(this)
        builder.setTitle("اختر معادلة")
        builder.setItems(names.toTypedArray()){ d, which ->
            // load structure only (no numbers)
            val selected = arr.getJSONObject(which)
            items.clear()
            val itemsArr = selected.getJSONArray("items")
            for(j in 0 until itemsArr.length()){
                val it = itemsArr.getJSONObject(j)
                items.add(Item(it.getString("name"), it.getString("type"), it.getDouble("value")))
            }
            adapter.notifyDataSetChanged()
        }
        builder.setNegativeButton("إلغاء"){ d, _ -> d.dismiss() }
        builder.show()
    }
}
